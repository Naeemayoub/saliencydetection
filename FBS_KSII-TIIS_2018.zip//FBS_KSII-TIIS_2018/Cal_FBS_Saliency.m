% The source code implements the saliency computation algorithm described in published work [1].  
% if you use this source code please cite our paper
%[1] Naeem Ayoub, Zhenguo Gao, Danjie Chen, Rachida Tobji and Nianmin Yao, 
% "Visual Saliency Detection Based on color Frequency Features under Bayesian framework,"
% KSII Transactions on Internet and Information Systems, vol. 12, no. 2, pp. 676-692, 2018. DOI: 10.3837/tiis.2018.02.008
%if you nedd any help
% please contact us on
%Email: naeemayoub666@gmail.com,
%%
clc;
clear all;
close all;
%% add path
addpath(genpath('./FBS'));
addpath(genpath('./ColorFeatures'));
%%
imgRoot = './imgs/';% test image path
saldir = './FBS_salmaps/';% the output path of the saliency map
mkdir(saldir);
imnames = dir([ imgRoot '*' 'jpg']);
for ii = 1:length(imnames)
    tic;
    disp(ii);  
    imgname = [ imgRoot imnames(ii).name ];
    img = imread(imgname);
    SM =FBS_Cal(img);
    toc;
    outname=[saldir imnames(ii).name(1:end-4) '' '.jpg'];
    imwrite(SM,outname); 
end